//
//  GameScene.swift
//  ElonGame
//
//  Created by Pratyush Sharma on 13/08/20.
//  Copyright © 2020 Pratyush Duklan. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    private var player: SKNode?
    private var joystick: SKNode?
    private var joystickKnob: SKNode?
    private var cameraNode: SKCameraNode?
    private var mountains1: SKNode?
    private var mountains2: SKNode?
    private var mountains3: SKNode?
    private var moon: SKNode?
    private var stars: SKNode?
    
    private var joystickAction: Bool = false
    private var rewardIsNotTouched: Bool = true
    private var knobRadius: CGFloat = 50.0
    
    private var previousTimeInterval: TimeInterval = 0
    private var playerFacingRight: Bool = true
    private var playerSpeed = 4.0
    
    private let scoreLabel: SKLabelNode = SKLabelNode()
    private var score = 0
    
    private var playerStateMachine: GKStateMachine!
    
    override func didMove(to view: SKView) {
        
        physicsWorld.contactDelegate = self

        player = childNode(withName: "player")
        joystick = childNode(withName: "joystick")
        joystickKnob = joystick?.childNode(withName: "knob")
        cameraNode = childNode(withName: "cameraNode") as? SKCameraNode
        moon = childNode(withName: "moon")
        stars = childNode(withName: "stars")
        mountains1 = childNode(withName: "mountain1")
        mountains2 = childNode(withName: "mountain2")
        mountains3 = childNode(withName: "mountain3")
        
        playerStateMachine = GKStateMachine(
            states: [JumpingState(playerNode: player!),
                     WalkingState(playerNode: player!),
                     IdleState(playerNode: player!),
                     LandingState(playerNode: player!),
                     StunnedState(playerNode: player!)]
        )
        
        playerStateMachine.enter(IdleState.self)
        
        //MARK: Spawn Meteor Timer
        Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { timer in
            self.spawnMeteor()
        }
        
        scoreLabel.position = CGPoint(x: (cameraNode?.position.x)! + 300, y: 100)
        scoreLabel.fontColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
        scoreLabel.fontSize = 24
        scoreLabel.fontName = "AvenirNext-Bold"
        scoreLabel.horizontalAlignmentMode = .right
        scoreLabel.text = "\(score)"
        cameraNode?.addChild(scoreLabel)
    }
}

//MARK:- Touches
extension GameScene {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            if let joystickKnob = joystickKnob {
                let location = touch.location(in: joystick!)
                joystickAction = joystickKnob.frame.contains(location)
            }
            
            let location = touch.location(in: self)
            if !(joystick?.contains(location))! {
                playerStateMachine.enter(JumpingState.self)
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let joystick = joystick else { return }
        guard let joystickKnob = joystickKnob else { return }
        
        if !joystickAction { return }
        
        for touch in touches {
            let position = touch.location(in: joystick)
            let length = sqrt(pow(position.y, 2) + pow(position.x, 2))
            let angle = atan2(position.y, position.x)
            
            if knobRadius > length {
                joystickKnob.position = position
            } else {
                joystickKnob.position = CGPoint(x: cos(angle) * knobRadius, y: sin(angle) * knobRadius)
            }
        }
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let xJoystickCoordinate = touch.location(in: joystick!).x
            let xLimit: CGFloat = 200.0
            
            if xJoystickCoordinate > -xLimit && xJoystickCoordinate < xLimit {
                resetKnobPostion()
            }
        }
    }
}

//MARK:- Action
extension GameScene {
    
    func resetKnobPostion() {
        let initialPoint = CGPoint(x: 0, y: 0)
        let moveBack = SKAction.move(to: initialPoint, duration: 0.1)
        moveBack.timingMode = .linear
        joystickKnob?.run(moveBack)
        joystickAction = false
    }
    
    func rewardTouch() {
        score += 1
        scoreLabel.text = "\(score)"
    }
}


//MARK:- Game Loop
extension GameScene {
    
    
    override func update(_ currentTime: TimeInterval) {
        let deltaTime = currentTime - previousTimeInterval
        previousTimeInterval = currentTime
        
        rewardIsNotTouched = true
        //Camera
        cameraNode?.position.x = player!.position.x
        joystick?.position.y = (cameraNode?.position.y)! - 100
        joystick?.position.x = (cameraNode?.position.x)! - 300 
        
        //Player movement
        guard let joystickKnob = joystickKnob else  { return }
        let xPosition = Double(joystickKnob.position.x)
        let positivePosition = xPosition < 0 ? -xPosition : xPosition
        
        if floor(positivePosition) != 0 {
            playerStateMachine.enter(WalkingState.self)
        } else {
            playerStateMachine.enter(IdleState.self)
        }
        let displacement = CGVector(dx: deltaTime * xPosition * playerSpeed, dy: 0.0)
        let move: SKAction = SKAction.move(by: displacement, duration: 0)
        var faceAction: SKAction = SKAction()
        let movingRight = xPosition > 0
        let movingLeft = xPosition < 0
        if movingLeft && playerFacingRight {
            playerFacingRight = false
            let faceMovement = SKAction.scaleX(to: -1.0, duration: 0.0)
            faceAction = SKAction.sequence([move, faceMovement])
        } else if movingRight && !playerFacingRight {
            playerFacingRight = true
            let faceMovement = SKAction.scaleX(to: 1.0, duration: 0.0)
            faceAction = SKAction.sequence([move, faceMovement])
        } else {
            faceAction = move
        }
        player?.run(faceAction)
        
        //Background Parallex
        let parallex1 = SKAction.moveTo(x: (player?.position.x)!/(-10), duration: 0.0)
        mountains1?.run(parallex1)
        
        let parallex2 = SKAction.moveTo(x: (player?.position.x)!/(-20), duration: 0.0)
        mountains2?.run(parallex2)
        
        let parallex3 = SKAction.moveTo(x: (player?.position.x)!/(-40), duration: 0.0)
        mountains3?.run(parallex3)
        
        let parallex4 = SKAction.moveTo(x: (cameraNode?.position.x)!, duration: 0.0)
        moon?.run(parallex4)
        
        let parallex5 = SKAction.moveTo(x: (cameraNode?.position.x)!, duration: 0.0)
        stars?.run(parallex5)
    }
}


//MARK:- Collision
extension GameScene: SKPhysicsContactDelegate {
    
    struct Collision {
        
        enum Masks: Int {
            case killing, player, reward, ground
            var bitMask: UInt32 {
                return 1 << self.rawValue
            }
        }
        
        let mask: (first: UInt32, second: UInt32)
        func matches(_ first: Masks, second: Masks) -> Bool {
            return (first.bitMask == mask.first && second.bitMask == mask.second) || (first.bitMask == mask.second && second.bitMask == mask.first)
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        let collision = Collision(mask: (first: contact.bodyA.categoryBitMask, second: contact.bodyB.categoryBitMask))
        
        if collision.matches(.player, second: .killing) {
            let die = SKAction.move(to: CGPoint(x: -300, y: -100), duration: 0.0)
            player?.run(die)
        }
        
        if collision.matches(.player, second: .ground) {
            playerStateMachine.enter(LandingState.self)
        }
        
        if collision.matches(.player, second: .reward){
            rewardTouch()
            if contact.bodyA.node?.name == "jewel", let reward = contact.bodyA.node {
                contact.bodyA.node?.physicsBody?.categoryBitMask = 0
                reward.removeFromParent()
            }
            if contact.bodyB.node?.name == "jewel", let reward = contact.bodyB.node {
                contact.bodyB.node?.physicsBody?.categoryBitMask = 0
                reward.removeFromParent()
            }
            
            if rewardIsNotTouched {
                rewardTouch()
                rewardIsNotTouched = false
            }
        }
        
        if collision.matches(.ground, second: .killing) {
            if contact.bodyA.node?.name == "Meteor", let meteor = contact.bodyA.node {
                createMolten(at: meteor.position)
                meteor.removeFromParent()
            }
            
            if contact.bodyB.node?.name == "Meteor", let meteor = contact.bodyB.node {
                createMolten(at: meteor.position)
                meteor.removeFromParent()
            }
        }
    }
    
    
    
}

//MARK:- Meteor
extension GameScene {
    
    func spawnMeteor() {
        let node: SKSpriteNode = SKSpriteNode(imageNamed: "meteor")
        node.name = "Meteor"
        let randamXPosition = Int(arc4random_uniform(UInt32(self.size.width)))
        node.position = CGPoint(x: randamXPosition, y: 270)
        node.anchorPoint = CGPoint(x: 0.5, y: 1)
        node.zPosition = 5
        node.physicsBody = SKPhysicsBody(circleOfRadius: 30.0)
        node.physicsBody?.categoryBitMask = Collision.Masks.killing.bitMask
        node.physicsBody?.collisionBitMask = Collision.Masks.player.bitMask | Collision.Masks.ground.bitMask
        node.physicsBody?.contactTestBitMask = Collision.Masks.player.bitMask | Collision.Masks.ground.bitMask
        node.physicsBody?.fieldBitMask = Collision.Masks.player.bitMask | Collision.Masks.ground.bitMask
        
        node.physicsBody?.affectedByGravity = true
        node.physicsBody?.allowsRotation = false
        node.physicsBody?.restitution = 0.2
        node.physicsBody?.friction = 10.0
        addChild(node)
    }
    
    func createMolten(at position: CGPoint) {
        let node = SKSpriteNode(imageNamed: "molten")
        node.position = CGPoint(x: position.x, y: position.y - 60.0)
        node.zPosition = 4
        
        addChild(node)
        
        let action = SKAction.sequence([
            .fadeIn(withDuration: 0.1),
             .wait(forDuration: 3.0),
             .fadeOut(withDuration: 0.2),
             .removeFromParent()
            ]
        )
        node.run(action)
    }
    
    
}
